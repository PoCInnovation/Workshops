let preCompile = {
  language: 'Solidity',
  sources: {
    'Inbox.sol': {
      content: ,// Put the contract content here (in utf-8 format).
    }
  },
  settings: {
    outputSelection: {
      '*': {
        '*': ['*']
      }
    }
  }
};