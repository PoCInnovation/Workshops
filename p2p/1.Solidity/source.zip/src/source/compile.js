let preCompile = {
  language: 'Solidity',
  sources: {
    'Inbox.sol': {
      content: '',// TODO : Put the contract content here (in utf-8 format).
    }
  },
  settings: {
    outputSelection: {
      '*': {
        '*': ['*']
      }
    }
  }
};

function compileContracts(contractCode) {
  // TODO : Use solcjs compiler to compile the contract (instead of null, a pretty useless contract).
  // Hints : Take a look at the link in the workshop subject and use the preCompile variable.
  const { contracts } = null;

  return contracts;
}

// TODO : Extract the abi & bytecode from the contract you've just compile and write them into files.