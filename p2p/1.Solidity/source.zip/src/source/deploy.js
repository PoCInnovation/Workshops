const HDWalletProvider = require('@truffle/hdwallet-provider');
const Web3 = require('web3');
require('dotenv').config();
// TODO : Update the .env file.
const provider = new HDWalletProvider(process.env.MMEMONIC, process.env.INFURA_ENDPOINT);
const web3 = new Web3(provider);

async function deploy(contractName, initalArgs) {
    const abi = require(`./out/${contractName}-abi.json`);
    const bytecode = require(`./out/${contractName}-bytecode.json`);
    const accounts = await web3.eth.getAccounts();

    // TODO : You've done this before ? ;)
    const contract = null;

    console.info('Contract deployed to address : ', contract.options.address);
}

deploy('Inbox', ['PoC']).then(() => {
    console.info('Exiting now');
    process.exit(0);
});