/**
 * Calls the submitProduct function of your smart contract which adds a product on the gloabl product list of your contract.
 *
 * @example
 *     buyProduct(web3, smartshop, account, 2)
 * @param web3
 * @param contract
 * @param {string} account
 * @param {number} amount
 * @param {number} productId
 */
const buyProduct = async (web3, contract, account, amount, productId) => {

}

/**
 * This function send a transaction to the submitProduct function of your smart contract.
 *
 * Then, the smart contract add your product with the argument you passed as parameters.
 * @example
 *     submitProduct(smartshop, account, "Nvidia RTX 3080", 2, "A graphic card mainly use to play Minecraft")
 * @param contract
 * @param {string} account
 * @param {string} productName
 * @param {number} productPrice
 * @param {string} productDescription
 */
const submitProduct = async (contract, account, productName, productPrice, productDescription) => {

}

/**
 * This function returns all the products available at the moment on the smartshop contract as a list.
 *
 * @example
 *     getProducts(smartshop)
 * @param contract
 */
const getProducts = async (contract) => {

}

module.exports = {
  submitProduct,
  buyProduct,
  getProducts,
}