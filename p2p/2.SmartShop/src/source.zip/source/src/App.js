import React, { useState } from 'react';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import web3 from "./web3";
import smartshop from "./smartshopcontract";
import { submitProduct, buyProduct, getProducts } from "./interact";
import './App.css';
import {Button, TextField} from "@material-ui/core";

function App() {
  const [accounts, setAccounts] = useState([]);
  const [products, setProducts] = useState([]);
  const [productName, setProductName] = useState("");
  const [productPrice, setProductPrice] = useState(0);
  const [productDescription, setProductDescription] = useState("");

  React.useEffect(() => {
    // TODO : Load the accounts provided by metamask here.
  }, []);

  async function handleSubmitProduct() {
    // TODO : Call the submitProduct & make the user wait until the transaction is done.
  }
  async function handleBuyProduct() {
    // TODO : Call the buyProduct & make the user wait until the transaction is done.
  }
  async function handleGetProducts() {
    // TODO : Call the getProducts & make the user wait until the transaction is done.
    // TODO : Update the product list here.
  }

  return (
    <MuiThemeProvider theme={createMuiTheme({
      typography: {
          "fontFamily": `"Roboto Mono", sans-serif`,
      }
    })
    }>
      <div>
        <h2 align="center">
          SmartShop
        </h2>
        <h4 align="center">
          {accounts.length === 0 ? "You need to load an ethereum account..." : `Login using the account : ${accounts[0]}`}
        </h4>
        {products.map((product, i) => {
          return (
            <div align="center" key={i}>
              <h4>
                {product}
              </h4>
            </div>)
        })}
        <div align="center" className="class">
          <Button variant="outlined" onClick={handleGetProducts}>
            Get Products
          </Button>
        </div>
        <div align="center" className="button">
          <div className="button">
            <TextField variant="outlined" label="Product ID"/>
          </div>
          <div>
            <Button variant="outlined" onClick={handleBuyProduct}>
              Buy product
            </Button>
          </div>
        </div>
        <div align="center" className="class">
          <div className="button">
            <TextField variant="outlined" label="Product name" value={productName} onChange={(event) => {
              setProductName(event.target.value);
            }}/>
          </div>
          <div className="button">
            <TextField variant="outlined" label="Product price" type="number" value={productPrice} onChange={(event) => {
              if (event.target.value === "") {
                return
              }
              setProductPrice(parseInt(event.target.value));
            }}/>
          </div>
          <div className="button">
            <TextField variant="outlined" label="Product description" value={productDescription} onChange={(event) => {
              setProductDescription(event.target.value);
            }}/>
          </div>
          <div>
            <Button variant="outlined" onClick={handleSubmitProduct}>
              Submit product
            </Button>
          </div>
        </div>
      </div>
    </MuiThemeProvider>
  );
}

export default App;
