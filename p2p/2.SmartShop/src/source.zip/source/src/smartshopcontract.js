import web3 from "./web3";

const address = ''; // Put the address of your deployed contract here.
const abi = []; // Put the abi of your deployed contract here.

export default new web3.eth.Contract(abi, address); // Will create a contract instance. It will allow you to interact with the contract functions & variables.