create user postgres;
create database postgres;
grant all privileges on database postgres to postgres;
create table musicfiles(id int);
