from django.apps import AppConfig


class MusicshareConfig(AppConfig):
    name = 'musicshare'
