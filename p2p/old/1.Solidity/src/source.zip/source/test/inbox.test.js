// TODO : Import the interface to interact with the contract.
// TODO : Import the bytecode to deploy the contract.
// Ganache is used to load fake ethereum accounts & a local network.
const ganache = require('ganache-cli');
const provider = ganache.provider();
// web3 will let you query the ethereum network using a provider.
const Web3 = require('web3');
// web3 will use the ganache provider for testing purposes.
const web3 = new Web3(provider);
// To make the assertions during tests.
const assert = require('assert');

// TODO : Define the functions to interact with the contract.
// Example :
// const getAccounts = async (web3) => {
//   return await web3.eth.getAccounts();
// };
// Will get the accounts loaded by ganache. Functions calls to Ethereum needs to be async.

describe('Inbox', () => {
    let accounts = undefined;
    let contract = undefined;
    let initialMsg = 'Hello World !';

    beforeEach(async () => {
        // TODO : Retrieve all ethereum accounts currently loaded.

        // TODO : Deploy the contract is required to interact with it and store it into the contract variable.
        // Hint : Take a look at the link given in the workshop subject.

    });

    // The first test will ensure that the contract has been properly deployed.
    it('has been deployed', () => {
        assert.ok(contract.options.address);
    });

    it('has a default message',async () => {
        // TODO : Test this feature.
    });

    it('can set a new message', async () => {
        // TODO : And this one too.
    });

    // TODO : Add more & more tests.
});
