package database

// Result is the common object result when
// aggregating relational data
type Result struct {
	Result string `json:"result"`
}
