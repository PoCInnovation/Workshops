import type * as grpc from '@grpc/grpc-js';
import type { MessageTypeDefinition } from '@grpc/proto-loader';

import type { ChatClient as _PoChat_ChatClient, ChatDefinition as _PoChat_ChatDefinition } from './PoChat/Chat';

type SubtypeConstructor<Constructor extends new (...args: any) => any, Subtype> = {
  new(...args: ConstructorParameters<Constructor>): Subtype;
};

export interface ProtoGrpcType {
  PoChat: {
    Chat: SubtypeConstructor<typeof grpc.Client, _PoChat_ChatClient> & { service: _PoChat_ChatDefinition }
    HelloRequest: MessageTypeDefinition
    HelloResponse: MessageTypeDefinition
  }
}

