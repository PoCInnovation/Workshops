// Original file: proto/pochat.proto


export interface HelloResponse {
  'content'?: (string);
}

export interface HelloResponse__Output {
  'content'?: (string);
}
