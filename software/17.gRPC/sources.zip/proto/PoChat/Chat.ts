// Original file: proto/pochat.proto

import type * as grpc from '@grpc/grpc-js'
import type { MethodDefinition } from '@grpc/proto-loader'
import type { HelloRequest as _PoChat_HelloRequest, HelloRequest__Output as _PoChat_HelloRequest__Output } from '../PoChat/HelloRequest';
import type { HelloResponse as _PoChat_HelloResponse, HelloResponse__Output as _PoChat_HelloResponse__Output } from '../PoChat/HelloResponse';

export interface ChatClient extends grpc.Client {
  Hello(argument: _PoChat_HelloRequest, metadata: grpc.Metadata, options: grpc.CallOptions, callback: (error?: grpc.ServiceError, result?: _PoChat_HelloResponse__Output) => void): grpc.ClientUnaryCall;
  Hello(argument: _PoChat_HelloRequest, metadata: grpc.Metadata, callback: (error?: grpc.ServiceError, result?: _PoChat_HelloResponse__Output) => void): grpc.ClientUnaryCall;
  Hello(argument: _PoChat_HelloRequest, options: grpc.CallOptions, callback: (error?: grpc.ServiceError, result?: _PoChat_HelloResponse__Output) => void): grpc.ClientUnaryCall;
  Hello(argument: _PoChat_HelloRequest, callback: (error?: grpc.ServiceError, result?: _PoChat_HelloResponse__Output) => void): grpc.ClientUnaryCall;
  hello(argument: _PoChat_HelloRequest, metadata: grpc.Metadata, options: grpc.CallOptions, callback: (error?: grpc.ServiceError, result?: _PoChat_HelloResponse__Output) => void): grpc.ClientUnaryCall;
  hello(argument: _PoChat_HelloRequest, metadata: grpc.Metadata, callback: (error?: grpc.ServiceError, result?: _PoChat_HelloResponse__Output) => void): grpc.ClientUnaryCall;
  hello(argument: _PoChat_HelloRequest, options: grpc.CallOptions, callback: (error?: grpc.ServiceError, result?: _PoChat_HelloResponse__Output) => void): grpc.ClientUnaryCall;
  hello(argument: _PoChat_HelloRequest, callback: (error?: grpc.ServiceError, result?: _PoChat_HelloResponse__Output) => void): grpc.ClientUnaryCall;
  
}

export interface ChatHandlers extends grpc.UntypedServiceImplementation {
  Hello: grpc.handleUnaryCall<_PoChat_HelloRequest__Output, _PoChat_HelloResponse>;
  
}

export interface ChatDefinition extends grpc.ServiceDefinition {
  Hello: MethodDefinition<_PoChat_HelloRequest, _PoChat_HelloResponse, _PoChat_HelloRequest__Output, _PoChat_HelloResponse__Output>
}
