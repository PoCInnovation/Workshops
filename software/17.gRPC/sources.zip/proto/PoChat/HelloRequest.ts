// Original file: proto/pochat.proto


export interface HelloRequest {
  'content'?: (string);
}

export interface HelloRequest__Output {
  'content'?: (string);
}
