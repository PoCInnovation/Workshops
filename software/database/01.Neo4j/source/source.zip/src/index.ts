import { dbConfig } from './config';

console.log('Welcome to the neo4j workshop !');
console.log('Actual configuration:');
console.log(dbConfig);
