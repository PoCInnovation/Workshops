import { Neogma } from 'neogma';

import { dbConfig } from './config';