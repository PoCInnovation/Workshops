import { get } from "env-var";
import express, { Request, Response } from "express";


const app = express();

const port: number = get('PORT').required().asPortNumber();

async function initServer() {
  app.listen(port, '0.0.0.0');
  console.log(`Server listening on http://localhost:${port}`);
}

async function main() {
  await initServer();

  app.get('/', (_req: Request, res: Response) => {
    res.send("Welcome to the workshop!")
  });
}

main()
  .catch((e) => console.error(e));
