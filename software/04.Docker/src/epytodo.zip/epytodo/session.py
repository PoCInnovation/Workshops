def init_global():
    global session
    session = -1
