function Hello() {
  console.log("Welcome to this Express workshop :)");
}

Hello();
