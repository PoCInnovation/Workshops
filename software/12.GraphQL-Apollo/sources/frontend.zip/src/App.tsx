import React from 'react';
import './App.css';

import AppBar from './AppBar/AppBar';

function App() {
	return (
		<div>
			<AppBar/>
		</div>
	);
}

export default App;
