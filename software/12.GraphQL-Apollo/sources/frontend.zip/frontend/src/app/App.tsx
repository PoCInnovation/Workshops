import './App.css';

import AppBar from '../components/AppBar';

function App() {
	return (
		<div>
			<AppBar/>
		</div>
	);
}

export default App;
