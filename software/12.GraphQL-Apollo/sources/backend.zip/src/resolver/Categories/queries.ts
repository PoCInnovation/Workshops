import { IResolvers } from 'apollo-server';

const queries: IResolvers = {
	Query: {},
};

export default queries;
