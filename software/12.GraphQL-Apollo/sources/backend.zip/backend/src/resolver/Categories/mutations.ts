import { IResolvers } from 'apollo-server';

const mutations: IResolvers = {
	Mutation: {},
};

export default mutations;
