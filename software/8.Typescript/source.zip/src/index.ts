function Hello() {
	console.log('Welcome to the national workshop :)');
}

Hello();
